module.exports = {
    PORT: 3000,
    MONGODB_URI: 'mongodb://localhost:27017/prova_banco'
};
