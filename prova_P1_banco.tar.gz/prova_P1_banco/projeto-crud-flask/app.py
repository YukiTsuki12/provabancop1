from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from pymongo import MongoClient

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres@localhost/prova_banco'
db = SQLAlchemy(app)

mongo_client = MongoClient('mongodb://localhost:27017/prova_banco')
mongo_db = mongo_client['prova_banco']
mongo_collection = mongo_db['User']

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), nullable=False, unique=True)
    password = db.Column(db.String(50), nullable=False)

with app.app_context():
    db.create_all()

@app.route('/')
def index():
    users_postgres = User.query.all()
    users_mongo = mongo_collection.find()
    return render_template('index.html', users_postgres=users_postgres, users_mongo=users_mongo)

@app.route('/add', methods=['POST'])
def add_user():
    username = request.form['username']
    password = request.form['password']
    
    try:
        new_user_postgres = User(username=username, password=password)
        db.session.add(new_user_postgres)
        db.session.commit()

        new_user_mongo = {'username': username, 'password': password}
        mongo_collection.insert_one(new_user_mongo)
        
        return redirect(url_for('index'))
    except Exception as e:
        print("Error:", e)
        return redirect(url_for('index'))



@app.route('/update/<int:id>', methods=['GET', 'POST'])
def update_user(id):
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        try:
            user_postgres = User.query.get_or_404(id)
            user_postgres.username = username
            user_postgres.password = password
            db.session.commit()

            mongo_collection.update_one({'_id': id}, {'$set': {'username': username, 'password': password}})
            
            return redirect(url_for('index'))
        except Exception as e:
            print("Error:", e)
            return redirect(url_for('index'))
    else:
        user_postgres = User.query.get_or_404(id)
        user_mongo = mongo_collection.find_one({'_id': id})

        if user_mongo:
            user = {'id': id, 'username': user_postgres.username, 'password': user_postgres.password}
        else:
            user = {'id': id, 'username': user_postgres.username, 'password': user_postgres.password}

        return render_template('update_user.html', user=user)

if __name__ == '__main__':
    app.run(debug=True)
